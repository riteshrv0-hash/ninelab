import { useState, useEffect } from 'react'
import { Menu, X, ArrowRight, Check, MapPin, Phone, Mail, Send, Sparkles, Code, Smartphone, Bot, Workflow, Database, BarChart3, MessageCircle, Zap, Shield } from 'lucide-react'

function App() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    phone: '',
    email: '',
    service: ''
  })

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible')
          }
        })
      },
      { threshold: 0.1 }
    )

    document.querySelectorAll('.reveal-on-scroll').forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const message = `Hi Ninelab, I'm interested in your services. My details:\nName: ${formData.name}\nCompany: ${formData.company}\nPhone: ${formData.phone}\nEmail: ${formData.email}\nService: ${formData.service}`
    window.open(`https://wa.me/918459803734?text=${encodeURIComponent(message)}`, '_blank')
  }

  const services = [
    {
      icon: <Code className="w-5 h-5" />,
      title: 'Website Development',
      description: 'Professional, mobile-responsive, SEO-optimized websites that convert visitors into customers.',
      price: 'Starting from ₹5,000'
    },
    {
      icon: <Smartphone className="w-5 h-5" />,
      title: 'Mobile Applications',
      description: 'Custom apps for your customers with push notifications, real-time updates, and seamless UX.',
      price: 'Starting from ₹50,000'
    },
    {
      icon: <Bot className="w-5 h-5" />,
      title: 'AI Chatbots',
      description: '24/7 AI-powered chatbots for customer support, lead generation, and automated responses.',
      price: 'Starting from ₹30,000'
    },
    {
      icon: <Workflow className="w-5 h-5" />,
      title: 'Automation',
      description: 'Streamline operations with automated workflows, reminders, and intelligent process management.',
      price: 'Starting from ₹20,000'
    },
    {
      icon: <Database className="w-5 h-5" />,
      title: 'ERP System',
      description: 'Complete enterprise resource planning for seamless management of all business operations.',
      price: 'Starting from ₹75,000'
    },
    {
      icon: <BarChart3 className="w-5 h-5" />,
      title: 'CRM & Lead Management',
      description: 'Track inquiries, automate follow-ups, and boost lead conversion with intelligent CRM.',
      price: 'Starting from ₹15,000'
    }
  ]

  const problems = [
    {
      title: 'Manual Operations',
      description: 'Wasting countless hours on repetitive tasks that could be automated.'
    },
    {
      title: 'Lost Leads',
      description: 'Up to 70% of potential customers lost due to poor follow-up systems.'
    },
    {
      title: 'Disorganized Data',
      description: 'Scattered information across multiple platforms causing chaos and inefficiency.'
    }
  ]

  const pricingTiers = [
    {
      name: 'Starter',
      price: '₹5,000',
      description: 'Perfect for small businesses getting started',
      features: [
        'Google Business Profile',
        'Basic Website',
        'WhatsApp Business API',
        'Email Support'
      ],
      popular: false
    },
    {
      name: 'Growth',
      price: '₹25,000',
      description: 'For growing businesses ready to scale',
      features: [
        'Modern Website',
        'Lead Management CRM',
        'Online Course Pages',
        'Analytics Dashboard',
        'Priority Support'
      ],
      popular: false
    },
    {
      name: 'Business',
      price: '₹75,000',
      description: 'Complete solution for established businesses',
      features: [
        'Complete ERP System',
        'Online Fee Collection',
        'Automated Reminders',
        'Student/Customer App',
        'API Integrations',
        'Dedicated Manager'
      ],
      popular: true
    },
    {
      name: 'Enterprise',
      price: '₹2,00,000',
      description: 'Full-featured solution for large organizations',
      features: [
        'AI Chatbot',
        'Predictive Analytics',
        'Auto Marketing',
        'Voice AI',
        'Custom Development',
        '24/7 Priority Support'
      ],
      popular: false
    }
  ]

  const processSteps = [
    {
      step: '01',
      title: 'Free Consultation',
      description: 'We understand your challenges and goals with no commitment required.'
    },
    {
      step: '02',
      title: 'Custom Proposal',
      description: 'Get a tailored solution recommendation that fits your budget and needs.'
    },
    {
      step: '03',
      title: 'Fast Development',
      description: 'Standard projects delivered in 7-14 days with regular updates.'
    },
    {
      step: '04',
      title: 'Launch & Support',
      description: 'We train your team, launch publicly, and provide ongoing support.'
    }
  ]

  const stats = [
    { value: '50+', label: 'Happy Clients' },
    { value: '15+', label: 'Cities Covered' },
    { value: '10,000+', label: 'Users Managed' },
    { value: '24/7', label: 'Support Available' }
  ]

  return (
    <div className="min-h-screen bg-ninelab-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-40 transition-all duration-200 ${isScrolled ? 'navbar-blur py-3' : 'py-6 bg-transparent'}`}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <span className="text-xl font-semibold tracking-tight">Ninelab</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#services" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors link-underline">Services</a>
              <a href="#pricing" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors link-underline">Pricing</a>
              <a href="#process" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors link-underline">Process</a>
              <a href="#contact" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors link-underline">Contact</a>
              <a
                href="https://wa.me/918459803734"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary px-5 py-2 text-sm"
              >
                Let's Talk
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-ninelab-black"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 bg-white border border-ninelab-border p-4">
              <div className="flex flex-col gap-4">
                <a href="#services" className="text-ninelab-gray hover:text-ninelab-black py-2" onClick={() => setMobileMenuOpen(false)}>Services</a>
                <a href="#pricing" className="text-ninelab-gray hover:text-ninelab-black py-2" onClick={() => setMobileMenuOpen(false)}>Pricing</a>
                <a href="#process" className="text-ninelab-gray hover:text-ninelab-black py-2" onClick={() => setMobileMenuOpen(false)}>Process</a>
                <a href="#contact" className="text-ninelab-gray hover:text-ninelab-black py-2" onClick={() => setMobileMenuOpen(false)}>Contact</a>
                <a
                  href="https://wa.me/918459803734"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary px-6 py-3 text-sm text-center"
                >
                  Let's Talk
                </a>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center pt-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-ninelab-light text-ninelab-gray text-xs tracking-wider uppercase mb-8">
              <Zap className="w-3.5 h-3.5" />
              Transform Your Business Digitally
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight tracking-tight">
              Go 99% Online with Ninelab
            </h1>

            <p className="text-lg md:text-xl text-ninelab-gray mb-10 max-w-xl mx-auto leading-relaxed">
              Complete IT solutions for modern businesses. From websites to AI chatbots, automation to ERP — we handle everything so you can focus on growth.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href="https://wa.me/918459803734?text=Hi%20Ninelab,%20I'm%20interested%20in%20your%20services"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary px-7 py-3 text-sm"
              >
                Book a Free Consultation
              </a>
              <a
                href="#services"
                className="btn-secondary px-7 py-3 text-sm"
              >
                View Our Solutions
              </a>
            </div>

            {/* Trust Badge */}
            <div className="mt-12 flex items-center justify-center gap-2 text-ninelab-gray text-sm">
              <div className="flex -space-x-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-7 h-7 rounded-full bg-ninelab-light border-2 border-white" />
                ))}
              </div>
              <span>Trusted by 50+ Businesses</span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 border-y border-ninelab-border bg-ninelab-light">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center reveal-on-scroll" style={{ transitionDelay: `${index * 100}ms` }}>
                <div className="stat-number mb-1">{stat.value}</div>
                <div className="text-ninelab-gray text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-spacing">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 reveal-on-scroll">
            <h2 className="text-3xl md:text-4xl font-bold mb-3 tracking-tight">
              Our Services
            </h2>
            <p className="text-ninelab-gray max-w-lg mx-auto">
              Comprehensive digital solutions tailored to transform your business operations and drive growth.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.map((service, index) => (
              <div
                key={index}
                className="clean-card reveal-on-scroll"
                style={{ transitionDelay: `${index * 50}ms` }}
              >
                <div className="w-10 h-10 bg-ninelab-light flex items-center justify-center mb-4">
                  {service.icon}
                </div>
                <h3 className="text-base font-semibold mb-2">{service.title}</h3>
                <p className="text-ninelab-gray text-sm mb-3 leading-relaxed">{service.description}</p>
                <div className="text-sm font-medium">{service.price}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Problems Section */}
      <section className="section-spacing bg-ninelab-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 reveal-on-scroll">
            <h2 className="text-3xl md:text-4xl font-bold mb-3 tracking-tight">
              Common Challenges
            </h2>
            <p className="text-ninelab-gray max-w-lg mx-auto">
              We understand the pain points that hold businesses back. Here's how we solve them.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {problems.map((problem, index) => (
              <div
                key={index}
                className="bg-white border border-ninelab-border p-8 reveal-on-scroll"
                style={{ transitionDelay: `${index * 50}ms` }}
              >
                <h3 className="text-base font-semibold mb-2">{problem.title}</h3>
                <p className="text-ninelab-gray text-sm leading-relaxed">{problem.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="section-spacing">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 reveal-on-scroll">
            <h2 className="text-3xl md:text-4xl font-bold mb-3 tracking-tight">
              Simple Pricing
            </h2>
            <p className="text-ninelab-gray max-w-lg mx-auto">
              Choose the perfect plan for your business. All plans include free consultation and dedicated support.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {pricingTiers.map((tier, index) => (
              <div
                key={index}
                className={`pricing-card ${tier.popular ? 'popular' : ''} reveal-on-scroll`}
                style={{ transitionDelay: `${index * 50}ms` }}
              >
                <h3 className="text-base font-semibold mb-1">{tier.name}</h3>
                <div className="text-2xl font-bold mb-1">{tier.price}</div>
                <p className="text-ninelab-gray text-xs mb-4">{tier.description}</p>
                <ul className="space-y-2 mb-6">
                  {tier.features.map((feature, i) => (
                    <li key={i} className="list-check text-xs">
                      <Check className="w-4 h-4" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <a
                  href="https://wa.me/918459803734"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`block w-full py-2.5 text-center text-sm font-medium transition-all ${
                    tier.popular
                      ? 'bg-ninelab-black text-white'
                      : 'border border-ninelab-black text-ninelab-black hover:bg-ninelab-black hover:text-white'
                  }`}
                >
                  Get Started
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section id="process" className="section-spacing bg-ninelab-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 reveal-on-scroll">
            <h2 className="text-3xl md:text-4xl font-bold mb-3 tracking-tight">
              How It Works
            </h2>
            <p className="text-ninelab-gray max-w-lg mx-auto">
              Our streamlined process ensures you get results quickly and efficiently.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {processSteps.map((step, index) => (
              <div
                key={index}
                className="reveal-on-scroll"
                style={{ transitionDelay: `${index * 50}ms` }}
              >
                <div className="bg-white border border-ninelab-border p-6 h-full">
                  <div className="text-3xl font-bold text-ninelab-gray mb-3">{step.step}</div>
                  <h3 className="text-base font-semibold mb-2">{step.title}</h3>
                  <p className="text-ninelab-gray text-sm leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section-spacing">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12 reveal-on-scroll">
              <h2 className="text-3xl md:text-4xl font-bold mb-3 tracking-tight">
                Get In Touch
              </h2>
              <p className="text-ninelab-gray">
                Ready to transform your business? Let's start a conversation.
              </p>
            </div>

            <div className="bg-white border border-ninelab-border p-8 md:p-10 reveal-on-scroll">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Your Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Company Name</label>
                    <input
                      type="text"
                      placeholder="Your Company"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="you@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Service Interested In *</label>
                  <select
                    required
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  >
                    <option value="">Select a service</option>
                    <option value="Website Development">Website Development</option>
                    <option value="Mobile Application">Mobile Application</option>
                    <option value="AI Chatbot">AI Chatbot</option>
                    <option value="Automation">Automation</option>
                    <option value="ERP System">ERP System</option>
                    <option value="CRM / Lead Management">CRM / Lead Management</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full btn-primary py-3.5 text-sm"
                >
                  Request Free Consultation
                </button>

                <p className="text-center text-ninelab-gray text-xs">
                  We will call you within 24 hours
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-ninelab-border">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="mb-4">
                <span className="text-lg font-semibold tracking-tight">Ninelab</span>
              </div>
              <p className="text-ninelab-gray text-sm max-w-md mb-6 leading-relaxed">
                Complete IT solutions for modern businesses. We help companies transform from offline to 99% online with cutting-edge technology.
              </p>
              <div className="flex gap-3">
                <a
                  href="https://wa.me/918459803734"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 bg-ninelab-light flex items-center justify-center hover:bg-ninelab-black hover:text-white transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
                <a
                  href="mailto:info@Ninelab"
                  className="w-9 h-9 bg-ninelab-light flex items-center justify-center hover:bg-ninelab-black hover:text-white transition-colors"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-sm font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#services" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors">Services</a></li>
                <li><a href="#pricing" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors">Pricing</a></li>
                <li><a href="#process" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors">Process</a></li>
                <li><a href="#contact" className="text-sm text-ninelab-gray hover:text-ninelab-black transition-colors">Contact</a></li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="text-sm font-semibold mb-4">Contact Us</h4>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-ninelab-gray">
                  <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>myHq office, Hinjewadi,<br />Pune 411033</span>
                </li>
                <li className="flex items-center gap-2 text-sm text-ninelab-gray">
                  <Phone className="w-4 h-4 shrink-0" />
                  <a href="tel:+918459803734" className="hover:text-ninelab-black transition-colors">+91 84598 03734</a>
                </li>
                <li className="flex items-center gap-2 text-sm text-ninelab-gray">
                  <Mail className="w-4 h-4 shrink-0" />
                  <a href="mailto:info@Ninelab" className="hover:text-ninelab-black transition-colors">info@Ninelab</a>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-ninelab-border flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-ninelab-gray text-xs">
              © 2024 Ninelab. All rights reserved.
            </p>
            <div className="flex items-center gap-2 text-ninelab-gray text-xs">
              <Shield className="w-3.5 h-3.5" />
              <span>Secure & Reliable Solutions</span>
            </div>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/918459803734?text=Hi%20Ninelab,%20I'm%20interested%20in%20your%20services"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-12 h-12 bg-ninelab-black text-white rounded-full flex items-center justify-center hover:bg-ninelab-gray transition-colors"
      >
        <MessageCircle className="w-5 h-5" />
      </a>
    </div>
  )
}

export default App
